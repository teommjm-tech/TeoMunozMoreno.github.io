var cab = document.getElementById('cabecera');
if (cab) {
  window.addEventListener('scroll', function () {
    cab.style.background = window.scrollY > 60
      ? 'rgba(14,28,47,0.99)'
      : 'rgba(14,28,47,0.94)';
  }, { passive: true });
}


var btnMenu = document.getElementById('boton-menu');
var nav     = document.getElementById('navegacion');
if (btnMenu && nav) {
  btnMenu.addEventListener('click', function () {
    nav.classList.toggle('abierta');
  });
  document.addEventListener('click', function (e) {
    if (cab && !cab.contains(e.target)) {
      nav.classList.remove('abierta');
    }
  });
}


var obs = new IntersectionObserver(function (entries) {
  entries.forEach(function (entry) {
    if (entry.isIntersecting) {
      entry.target.style.opacity  = '1';
      entry.target.style.transform = 'translateY(0)';
      obs.unobserve(entry.target);
    }
  });
}, { threshold: 0.07 });

document.querySelectorAll('.tarjeta-hotel, .tarjeta-destino, .valor').forEach(function (el) {
  el.style.opacity   = '0';
  el.style.transform = 'translateY(18px)';
  el.style.transition = 'opacity .5s ease, transform .5s ease';
  obs.observe(el);
});