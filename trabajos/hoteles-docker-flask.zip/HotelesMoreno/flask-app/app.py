import os
import urllib.request
import threading
import mysql.connector
from mysql.connector import Error
from flask import Flask, render_template, request, jsonify, redirect, url_for
from datetime import date

app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False


DB = {
    'host':        os.environ.get('DB_HOST', 'mysql'),
    'port':        int(os.environ.get('DB_PORT', 3306)),
    'database':    os.environ.get('DB_NAME', 'luxstay_db'),
    'user':        os.environ.get('DB_USER', 'luxstay_user'),
    'password':    os.environ.get('DB_PASSWORD', 'luxstay_pass'),
    'charset':     'utf8mb4',
    'use_unicode': True,
}

def db():
    return mysql.connector.connect(**DB)


IMG_DIR = os.path.join(os.path.dirname(__file__), 'static', 'img')
os.makedirs(IMG_DIR, exist_ok=True)

FOTOS = {
    'h01_p.jpg': 'https://images.unsplash.com/photo-1551882547-ff40c4a49ce7?w=700&q=80',
    'h01_d.jpg': 'https://images.unsplash.com/photo-1551882547-ff40c4a49ce7?w=1100&q=80',
    'h02_p.jpg': 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=700&q=80',
    'h02_d.jpg': 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=1100&q=80',
    'h03_p.jpg': 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=700&q=80',
    'h03_d.jpg': 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=1100&q=80',
    'h04_p.jpg': 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=700&q=80',
    'h04_d.jpg': 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=1100&q=80',
    'h05_p.jpg': 'https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=700&q=80',
    'h05_d.jpg': 'https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=1100&q=80',
    'h06_p.jpg': 'https://images.unsplash.com/photo-1582719508461-905c673771fd?w=700&q=80',
    'h06_d.jpg': 'https://images.unsplash.com/photo-1582719508461-905c673771fd?w=1100&q=80',
    'h07_p.jpg': 'https://images.unsplash.com/photo-1455587734955-081b22074882?w=700&q=80',
    'h07_d.jpg': 'https://images.unsplash.com/photo-1455587734955-081b22074882?w=1100&q=80',
    'h08_p.jpg': 'https://images.unsplash.com/photo-1586611292717-f828b167408c?w=700&q=80',
    'h08_d.jpg': 'https://images.unsplash.com/photo-1586611292717-f828b167408c?w=1100&q=80',
    'h09_p.jpg': 'https://images.unsplash.com/photo-1549294413-26f195200c16?w=700&q=80',
    'h09_d.jpg': 'https://images.unsplash.com/photo-1549294413-26f195200c16?w=1100&q=80',
    'h10_p.jpg': 'https://images.unsplash.com/photo-1566665797739-1674de7a421a?w=700&q=80',
    'h10_d.jpg': 'https://images.unsplash.com/photo-1566665797739-1674de7a421a?w=1100&q=80',
    'h11_p.jpg': 'https://images.unsplash.com/photo-1445019980597-93fa8acb246c?w=700&q=80',
    'h11_d.jpg': 'https://images.unsplash.com/photo-1445019980597-93fa8acb246c?w=1100&q=80',
    'h12_p.jpg': 'https://images.unsplash.com/photo-1568084680786-a84f91d1153c?w=700&q=80',
    'h12_d.jpg': 'https://images.unsplash.com/photo-1568084680786-a84f91d1153c?w=1100&q=80',
    'h13_p.jpg': 'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?w=700&q=80',
    'h13_d.jpg': 'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?w=1100&q=80',
    'h14_p.jpg': 'https://images.unsplash.com/photo-1615460549969-36fa19521a4f?w=700&q=80',
    'h14_d.jpg': 'https://images.unsplash.com/photo-1615460549969-36fa19521a4f?w=1100&q=80',
    'h15_p.jpg': 'https://images.unsplash.com/photo-1561501900-3701fa6a0864?w=700&q=80',
    'h15_d.jpg': 'https://images.unsplash.com/photo-1561501900-3701fa6a0864?w=1100&q=80',
    'h16_p.jpg': 'https://images.unsplash.com/photo-1522798514-97ceb8c4f1c8?w=700&q=80',
    'h16_d.jpg': 'https://images.unsplash.com/photo-1522798514-97ceb8c4f1c8?w=1100&q=80',
}

def _descargar_fotos():
    ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    for nombre, url in FOTOS.items():
        ruta = os.path.join(IMG_DIR, nombre)
        if os.path.exists(ruta) and os.path.getsize(ruta) > 5000:
            continue
        try:
            req = urllib.request.Request(url, headers={'User-Agent': ua})
            with urllib.request.urlopen(req, timeout=20) as r:
                datos = r.read()
            if len(datos) > 5000:
                with open(ruta, 'wb') as f:
                    f.write(datos)
                print(f'[IMG] OK: {nombre}')
        except Exception as e:
            print(f'[IMG] Error {nombre}: {e}')

threading.Thread(target=_descargar_fotos, daemon=True).start()



def calcular_noches(entrada, salida):
    try:
        d1 = date.fromisoformat(entrada)
        d2 = date.fromisoformat(salida)
        return (d2 - d1).days
    except Exception:
        return 0




@app.route('/')
def inicio():
    return render_template('inicio.html')


    # FLASK RECIBE LA BUSQUEDA ej.1 (5)
@app.route('/buscar')
def buscar():
    ciudad  = request.args.get('ciudad', '').strip()
    entrada = request.args.get('fecha_entrada', '')
    salida  = request.args.get('fecha_salida', '')
    nhab    = request.args.get('numero_habitaciones', 1, type=int)
    error   = None
    hoteles = []
    //

    if not (ciudad and entrada and salida):
        return redirect(url_for('inicio'))


    # VALIDACION EN EL SERVIDOR ej.1 (6)
    noches = calcular_noches(entrada, salida)
    if noches <= 0:
        error = 'La fecha de salida debe ser posterior a la fecha de llegada.'
    //


        return render_template('resultados.html',
            hoteles=[], ciudad=ciudad,
            fecha_entrada=entrada, fecha_salida=salida,
            numero_habitaciones=nhab, noches=0, error=error)

    if nhab < 1:
        error = 'El numero de habitaciones debe ser al menos 1.'
        return render_template('resultados.html',
            hoteles=[], ciudad=ciudad,
            fecha_entrada=entrada, fecha_salida=salida,
            numero_habitaciones=nhab, noches=noches, error=error)

    try:
        con = db()
        cur = con.cursor(dictionary=True)


        # CONSULTA SQL ej.1 (7)
        cur.execute("""
            SELECT h.*,
                   h.numero_habitaciones
                   - COALESCE(SUM(r.numero_habitaciones), 0) AS disponibles
            FROM hoteles h
            LEFT JOIN reservas r
                   ON r.hotel_id     = h.id
                  AND r.fecha_entrada < %s
                  AND r.fecha_salida  > %s
            WHERE LOWER(h.ciudad) = LOWER(%s)
            GROUP BY h.id
            HAVING disponibles >= %s
            ORDER BY h.precio_noche
        """, (salida, entrada, ciudad, nhab))
        //


        hoteles = cur.fetchall()
        cur.close()
        con.close()
    except Error as e:
        error = str(e)


    # PAGINA DE RESULTADOS ej.1 (8)
    return render_template('resultados.html',
        hoteles=hoteles, ciudad=ciudad,
        fecha_entrada=entrada, fecha_salida=salida,
        numero_habitaciones=nhab, noches=noches, error=error)
        //


# FLASK CARGA EL DETALLE ej.2 (2)
@app.route('/hotel/<int:hid>')
def detalle(hid):
    entrada = request.args.get('fecha_entrada', '')
    salida  = request.args.get('fecha_salida', '')
    nhab    = request.args.get('numero_habitaciones', 1, type=int)
    hotel   = None
    error   = None
    //

    try:
        con = db()
        cur = con.cursor(dictionary=True)


        #BUSCA EL HOTEL EN BASE DE DATOS ej.2 (3)
        cur.execute('SELECT * FROM hoteles WHERE id = %s', (hid,))
        hotel = cur.fetchone()
        //

        if hotel and entrada and salida:

            # CALCULA HABITACIONES DISPONIBLES ej.2 (4)
            cur.execute("""
                SELECT COALESCE(SUM(numero_habitaciones), 0) AS ocupadas
                FROM reservas
                WHERE hotel_id = %s
                  AND fecha_entrada < %s
                  AND fecha_salida  > %s
            """, (hid, salida, entrada))
            hotel['disponibles'] = hotel['numero_habitaciones'] - cur.fetchone()['ocupadas']
            //

        cur.close()
        con.close()
    except Error as e:
        error = str(e)

    if not hotel:
        return redirect(url_for('inicio'))

    return render_template('detalle.html',
        hotel=hotel, fecha_entrada=entrada,
        fecha_salida=salida, numero_habitaciones=nhab, error=error)

# FLASK RECIBE EL FORMULARIO DE RESERVA ej.3 (4)
@app.route('/reservar', methods=['POST'])
def reservar():
    hid     = request.form.get('hotel_id', type=int)
    cliente = request.form.get('nombre_cliente', '').strip()
    entrada = request.form.get('fecha_entrada', '')
    salida  = request.form.get('fecha_salida', '')
    nhab    = request.form.get('numero_habitaciones', 1, type=int)
//

    resultado  = ''
    exito      = False
    reserva_id = None
    error_msg  = None

# VALIDACIONES PYTHON EJ.3 (5)
    if not cliente:
        error_msg = 'El nombre del titular no puede estar vacio.'
    elif calcular_noches(entrada, salida) <= 0:
        error_msg = 'La fecha de salida debe ser posterior a la fecha de llegada.'
//


    elif nhab < 1:
        error_msg = 'El numero de habitaciones debe ser al menos 1.'
    else:
        try:
            con = db()
            cur = con.cursor()

            # LLAMADA A PROCEDIMIENTO ALMACENADO ej.3 (6)
            out_args = cur.callproc('realizar_reserva',
                [hid, cliente, entrada, salida, nhab, ''])
            //


            for _ in cur.stored_results():
                pass



            if out_args and len(out_args) >= 6 and out_args[5] is not None:
                resultado = str(out_args[5])
            else:
                cur.execute('SELECT @_realizar_reserva_5')
                fila = cur.fetchone()
                resultado = str(fila[0]) if (fila and fila[0] is not None) else ''

            con.commit()
            cur.close()
            con.close()


            # FLASK LEE EL RESULTADO Y MUESTRA LA CONFIGURACION ej.3 (9)
            if resultado.startswith('OK:'):
                exito      = True
                reserva_id = resultado.split(':')[1]
            elif resultado:
                error_msg = resultado
            ##


            else:
                error_msg = 'No se pudo obtener respuesta del servidor.'
        except Error as e:
            error_msg = str(e)

    nombre_hotel = ciudad_hotel = ''
    try:
        con = db()
        cur = con.cursor(dictionary=True)
        cur.execute('SELECT nombre, ciudad FROM hoteles WHERE id = %s', (hid,))
        h = cur.fetchone()
        if h:
            nombre_hotel = h['nombre']
            ciudad_hotel = h['ciudad']
        cur.close()
        con.close()
    except Error:
        pass


    # FLASK LEE EL RESULTADO Y MUESTRA LA CONFIGURACION ej.3 (9)
    return render_template('confirmacion.html',
        exito=exito, reserva_id=reserva_id, error_msg=error_msg,
        hotel_id=hid, nombre_hotel=nombre_hotel, ciudad_hotel=ciudad_hotel,
        nombre_cliente=cliente, fecha_entrada=entrada,
        fecha_salida=salida, numero_habitaciones=nhab)
    ##


@app.route('/admin')
def admin():
    reservas  = []
    auditoria = []
    error     = None
    try:
        con = db()
        cur = con.cursor(dictionary=True)

        cur.execute("""
            SELECT r.id, h.nombre AS hotel, h.ciudad,
                   r.nombre_cliente, r.fecha_entrada, r.fecha_salida,
                   r.numero_habitaciones,
                   DATEDIFF(r.fecha_salida, r.fecha_entrada) AS noches,
                   DATEDIFF(r.fecha_salida, r.fecha_entrada)
                     * r.numero_habitaciones * h.precio_noche AS importe
            FROM reservas r
            JOIN hoteles h ON h.id = r.hotel_id
            ORDER BY r.id DESC
        """)
        reservas = cur.fetchall()

        cur.execute("""
            SELECT a.id, h.nombre AS hotel, a.reserva_id, a.fecha_hora
            FROM auditoria_reservas a
            JOIN hoteles h ON h.id = a.hotel_id
            ORDER BY a.id DESC
            LIMIT 50
        """)
        auditoria = cur.fetchall()

        cur.close()
        con.close()
    except Error as e:
        error = str(e)

    return render_template('admin.html',
        reservas=reservas, auditoria=auditoria, error=error)


@app.route('/api/ciudades')
def ciudades():
    try:
        con = db()
        cur = con.cursor()
        cur.execute('SELECT DISTINCT ciudad FROM hoteles ORDER BY ciudad')
        lista = [r[0] for r in cur.fetchall()]
        cur.close()
        con.close()
        return jsonify(lista)
    except Error:
        return jsonify([])


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)