SET NAMES utf8mb4;
USE luxstay_db;

ALTER DATABASE luxstay_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- -----------------------------------------------------------
-- TABLAS
-- -----------------------------------------------------------

CREATE TABLE IF NOT EXISTS hoteles (
    id                  INT           PRIMARY KEY AUTO_INCREMENT,
    nombre              VARCHAR(100)  NOT NULL,
    ciudad              VARCHAR(50)   NOT NULL,
    descripcion         TEXT,
    precio_noche        DECIMAL(10,2) NOT NULL,
    numero_habitaciones INT           NOT NULL,
    imagen_principal    VARCHAR(255),
    imagen_secundaria   VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS reservas (
    id                  INT          PRIMARY KEY AUTO_INCREMENT,
    hotel_id            INT          NOT NULL,
    nombre_cliente      VARCHAR(100) NOT NULL,
    fecha_entrada       DATE         NOT NULL,
    fecha_salida        DATE         NOT NULL,
    numero_habitaciones INT          NOT NULL,
    CONSTRAINT fk_hotel FOREIGN KEY (hotel_id) REFERENCES hoteles(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS auditoria_reservas (
    id         INT      PRIMARY KEY AUTO_INCREMENT,
    hotel_id   INT      NOT NULL,
    reserva_id INT      NOT NULL,
    fecha_hora DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------
-- PROCEDIMIENTO ALMACENADO
-- Comprueba disponibilidad e inserta la reserva
-- -----------------------------------------------------------

DROP PROCEDURE IF EXISTS realizar_reserva;

DELIMITER $$

CREATE PROCEDURE realizar_reserva(
    IN  p_hotel_id    INT,
    IN  p_cliente     VARCHAR(100),
    IN  p_entrada     DATE,
    IN  p_salida      DATE,
    IN  p_habitaciones INT,
    OUT p_resultado   VARCHAR(250)
)
BEGIN
    DECLARE v_total      INT DEFAULT 0;
    DECLARE v_ocupadas   INT DEFAULT 0;
    DECLARE v_disponibles INT DEFAULT 0;

    -- Obtener capacidad total del hotel
    SELECT numero_habitaciones INTO v_total
    FROM hoteles WHERE id = p_hotel_id;

    IF v_total IS NULL THEN
        SET p_resultado = 'ERROR: Hotel no encontrado.';
    ELSE


        -- ESTE ES EL PROCEDIMIENTO ALMACENADO ej.3 (7)
        SELECT COALESCE(SUM(numero_habitaciones), 0) INTO v_ocupadas
        FROM reservas
        WHERE hotel_id    = p_hotel_id
          AND fecha_entrada < p_salida
          AND fecha_salida  > p_entrada;

        SET v_disponibles = v_total - v_ocupadas;

        IF p_habitaciones <= 0 THEN
            SET p_resultado = 'ERROR: El numero de habitaciones debe ser al menos 1.';
        ELSEIF p_habitaciones > v_disponibles THEN
            SET p_resultado = CONCAT('ERROR: Solo hay ', v_disponibles, ' habitaciones disponibles para esas fechas.');
        ELSE
            INSERT INTO reservas (hotel_id, nombre_cliente, fecha_entrada, fecha_salida, numero_habitaciones)
            VALUES (p_hotel_id, p_cliente, p_entrada, p_salida, p_habitaciones);

            SET p_resultado = CONCAT('OK:', LAST_INSERT_ID());
        END IF;
        -- FIN PROCEDIMIENTO ALMACENADO ej.3 (7)


    END IF;
END$$

DELIMITER ;

-- -----------------------------------------------------------
-- TRIGGER: auditoria automatica tras cada reserva
-- -----------------------------------------------------------

DROP TRIGGER IF EXISTS trg_auditoria;

DELIMITER $$

-- EL TRIGGER SE ACTIVA SOLO ej.3 (8)
CREATE TRIGGER trg_auditoria
AFTER INSERT ON reservas
FOR EACH ROW
BEGIN
    INSERT INTO auditoria_reservas (hotel_id, reserva_id, fecha_hora)
    VALUES (NEW.hotel_id, NEW.id, NOW());
END$$
-- FIN TRIGGER ej.3 (8)

DELIMITER ;

-- -----------------------------------------------------------
-- DATOS: 2 hoteles por ciudad (16 en total)
-- Las imagenes se descargan automaticamente al arrancar Flask
-- -----------------------------------------------------------

INSERT INTO hoteles (nombre, ciudad, descripcion, precio_noche, numero_habitaciones, imagen_principal, imagen_secundaria) VALUES

-- MADRID
('Gran Hotel Velazquez', 'Madrid',
'Situado en el Paseo de la Castellana, el Gran Hotel Velazquez lleva mas de ochenta anos siendo uno de los referentes de la hospitalidad madrilena. Sus 72 habitaciones combinan el clasicismo del edificio, construido en los anos cuarenta, con todas las comodidades que se esperan hoy en dia: suelos de marmol de Macael, techos artesonados a cinco metros de altura y ventanas que dan a uno de los bulevares mas elegantes de Europa. El restaurante del hotel, con cocina de mercado y carta que cambia cada semana, es lugar de encuentro habitual de la vida cultural de la ciudad. A cinco minutos andando del Museo del Prado y del Parque del Retiro.',
185.00, 72, '/static/img/h01_p.jpg', '/static/img/h01_d.jpg'),

('Palacio de Cibeles Suites', 'Madrid',
'Ocupa la quinta y sexta planta de uno de los edificios mas emblematicos de la Gran Via, con vistas directas a la Plaza de Cibeles que muy pocos hoteles de la capital pueden ofrecer. Las 48 habitaciones conservan los techos altos y las molduras originales de la arquitectura de principios del siglo XX, y el mobiliario, disenado en exclusiva por un estudio madrileno, juega con el azul noche y los acabados en laton. La terraza panoramica, abierta de mayo a septiembre, se ha convertido en uno de los planes favoritos de los madrilenos para el aperitivo del domingo.',
215.00, 48, '/static/img/h02_p.jpg', '/static/img/h02_d.jpg'),

-- BARCELONA
('Hotel del Mar Barcelona', 'Barcelona',
'A doscientos metros de la playa de la Barceloneta y con vistas directas al Mediterraneo desde todas sus habitaciones, el Hotel del Mar es uno de esos lugares que enamoran desde el primer momento. El edificio, rehabilitado en 2019 respetando la fachada modernista original, alberga 60 habitaciones con terraza privada, suelo de microcemento pulido y bano con productos de cosmética artesanal catalana. El restaurante firma una cocina que va del boqueron en vinagre a la gamba de Palamos, siempre con producto fresco del dia. La piscina exterior, rodeada de tumbonas de teca y con barra de cocteles, tiene ese sabor de chiringuito de lujo que tan bien le sienta a Barcelona.',
225.00, 60, '/static/img/h03_p.jpg', '/static/img/h03_d.jpg'),

('Boutique Hotel Born', 'Barcelona',
'Escondido en una callejuela empedrada del barrio del Born, a cincuenta metros del Palau de la Musica Catalana y a dos pasos del mercado de Santa Caterina, el Boutique Hotel Born es el sitio perfecto para quien quiera vivir Barcelona desde adentro. Sus 32 habitaciones tienen paredes de piedra vista, vigas de madera originales del siglo XVIII y ducha de efecto lluvia. El desayuno, servido en el patio interior con naranjos, incluye pan con tomate, embutidos artesanos y zumo de frutas de temporada. El personal conoce la ciudad como la palma de su mano y tiene siempre una mesa reservada en el mejor bar de vermut del barrio.',
158.00, 32, '/static/img/h04_p.jpg', '/static/img/h04_d.jpg'),

-- SEVILLA
('Casa Palacio Guadalquivir', 'Sevilla',
'Frente al rio Guadalquivir y a cinco minutos andando de la Torre del Oro, esta casa palacio del siglo XVIII fue restaurada con mucho criterio hace diez anos. Los 45 puestos de alojamiento se reparten entre habitaciones y junior suites, todas con suelo de barro cocido sevillano y azulejos de Triana pintados a mano. El patio andaluz central, con naranjos y una fuente de ceramica azul y blanca, es el corazon del edificio y el lugar donde se sirve el desayuno de marzo a noviembre. Desde la azotea, con hamacas y un pequeno bar, se ve la Giralda iluminada al caer la noche.',
165.00, 45, '/static/img/h05_p.jpg', '/static/img/h05_d.jpg'),

('Hotel Santa Cruz', 'Sevilla',
'Metido en una callejuela del barrio de Santa Cruz, el barrio judio medieval de Sevilla, el Hotel Santa Cruz es lo mas parecido a alojarse en casa de una familia noble sevillana del siglo XIX. Solo tiene 20 habitaciones, distribuidas en torno a dos patios con arcos y macetas de geranios rojos. Cada cuarto tiene nombre propio: El de la Giralda, El del Naranjal, El de los Azulejos. El dueno, que lleva toda su vida aqui, sabe exactamente donde comer las mejores tapas de la ciudad y siempre tiene tiempo para contarlo.',
148.00, 20, '/static/img/h06_p.jpg', '/static/img/h06_d.jpg'),

-- GRANADA
('Hotel Alhambra Palace', 'Granada',
'A trescientos metros de la Alhambra, en una callejuela empedrada del Albaicin con vistas directas a la Sabika, este hotel de 38 habitaciones fue en su dia un carmen nazari del siglo XIV. La rehabilitacion, llevada a cabo por un arquitecto granadino especialista en patrimonio, conservo los techos de mocaragoces, las yeserias originales, el jardin con alberca y los miradores de madera. Desde la terraza se ve el conjunto de la Alhambra iluminada al anochecer, una de las estampas mas impresionantes de Espana. El desayuno incluye productos de la Alpujarra: miel de acacia, queso de Trevelez y zumo de naranja recien exprimida.',
152.00, 38, '/static/img/h07_p.jpg', '/static/img/h07_d.jpg'),

('Hotel Carmen del Darro', 'Granada',
'A orillas del rio Darro, con el barrio del Sacromonte al fondo y el sonido del agua como banda sonora permanente, el Hotel Carmen del Darro es posiblemente el hotel con mas encanto de Granada. Sus 18 habitaciones tienen vistas al rio o al jardin interior, y la decoracion mezcla lo andaluz con antiguedades que el propietario fue recogiendo en viajes por el Magreb y el Levante. Por las noches, si las ventanas estan abiertas, el flamenco del Sacromonte llega hasta las camas.',
135.00, 18, '/static/img/h08_p.jpg', '/static/img/h08_d.jpg'),

-- SAN SEBASTIAN
('Hotel La Concha', 'San Sebastian',
'Frente a la bahia de la Concha, con vistas directas al mar desde todas sus habitaciones y al monte Igeldo desde las de la parte trasera, el Hotel La Concha lleva siendo el hotel de referencia de San Sebastian desde que abrio sus puertas en 1912. Las 55 habitaciones tienen ese aire clasico del turismo de principios del siglo XX, con molduras, papel pintado y banos en marmol blanco. El bar sirve los mejores pintxos de la zona: anchoa del Cantabrico sobre pan de hogaza, foie micuit con mermelada de higos y txangurro relleno al horno.',
295.00, 55, '/static/img/h09_p.jpg', '/static/img/h09_d.jpg'),

('Cantabrico Suites Gros', 'San Sebastian',
'En la parte alta del barrio de Gros, a doscientos metros de la playa de Zurriola y con vistas al monte Urgull desde la terraza, el Cantabrico Suites es el hotel favorito de quienes vienen a San Sebastian a comer bien y descansar. Sus 35 suites tienen cocina americana equipada con electrodomesticos Miele, perfecta para quien quiera llevar al apartamento lo que encuentre en el mercado de La Bretxa. El chef del restaurante trabaja exclusivamente con productores del Pais Vasco y Navarra: nada que no haya crecido o vivido a menos de cien kilometros.',
268.00, 35, '/static/img/h10_p.jpg', '/static/img/h10_d.jpg'),

-- TOLEDO
('Parador San Juan de los Reyes', 'Toledo',
'Instalado en un convento franciscano del siglo XV a dos pasos de la iglesia de San Juan de los Reyes y a cinco minutos andando de la Catedral Primada, este parador es el alojamiento mas especial de Toledo. Sus 55 habitaciones conservan boveda de cruceria gotica, vigas de roble y ventanas con arco apuntado que dan al claustro o a la ciudad historica. El comedor, con la piedra original a la vista y el techo a diez metros de altura, sirve una cocina castellana de producto: carcamusas, perdiz estofada y mazapan de postre.',
138.00, 55, '/static/img/h11_p.jpg', '/static/img/h11_d.jpg'),

('Hotel El Greco Toledo', 'Toledo',
'En el barrio judio de Toledo, en una casa del siglo XVI que pertenecio a una familia de comerciantes de seda, el Hotel El Greco tiene 33 habitaciones que huelen a madera vieja y jabones artesanales de romero y espliego. Las paredes son de piedra caliza local, el mismo material que la catedral que se ve desde el comedor del desayuno. El propietario, toledano de quinta generacion, organiza visitas nocturnas privadas al casco historico para los huespedes que se lo pidan.',
118.00, 33, '/static/img/h12_p.jpg', '/static/img/h12_d.jpg'),

-- VALENCIA
('Hotel Palau de la Mar', 'Valencia',
'Instalado en dos palacetes neoclasicos del siglo XIX en el ensanche historico de Valencia, el Hotel Palau de la Mar combina la arquitectura burguesa valenciana con un interiorismo contemporaneo muy cuidado. Las 66 habitaciones tienen suelo de mosaico hidraulico original, techos con estucos y en las suites banera exenta con vistas al jardin interior. La piscina cubierta con luz natural y el spa con sauna finlandesa y sala de vapores lo convierten en una opcion ideal para quien quiera descansar de verdad.',
198.00, 66, '/static/img/h13_p.jpg', '/static/img/h13_d.jpg'),

('Hotel Cabanyal Valencia', 'Valencia',
'A cien metros de la playa de la Malvarrosa, en pleno barrio del Cabanyal con sus casas de colores y sus azulejos marineros, el Hotel Cabanyal es el punto de partida perfecto para explorar la Valencia menos turistica. Sus 42 habitaciones tienen ese estilo limpio y luminoso del Mediterraneo, con tonos blancos, madera clara y ventiladores de techo. El restaurante propone arroces caldosos y paellas autenticas hechas al fuego de lena, y las bicicletas del hotel son gratuitas para llegar pedaleando al centro por el jardin del Turia.',
148.00, 42, '/static/img/h14_p.jpg', '/static/img/h14_d.jpg'),

-- OVIEDO
('Hotel de la Reconquista', 'Oviedo',
'El edificio mas imponente de Oviedo, un hospicio barroco del siglo XVIII declarado Monumento Nacional, convertido en el hotel de referencia del norte de Espana. Sus 142 habitaciones rodean un patio central de proporciones perfectas donde en verano se celebran conciertos de camara. La fachada de piedra caliza, con su portalon de columnas, domina el corazon de la ciudad. El restaurante es uno de los mejores de Asturias: fabada con fabe de la granja, cachopo de ternera asturiana y tarta de queso Afuega el Pitu de postre.',
178.00, 142, '/static/img/h15_p.jpg', '/static/img/h15_d.jpg'),

('Hotel Picos de Europa', 'Oviedo',
'A diez minutos del casco historico de Oviedo y a menos de una hora en coche del Parque Nacional de los Picos de Europa y de la costa asturiana, este hotel de 40 habitaciones es el cuartel general perfecto para explorar Asturias. La fachada de piedra del Naranco se mimetiza con el paisaje. El restaurante es conocido en la region por su fabada, elaborada con ingredientes de productores de confianza de la comarca, y la bodega tiene mas de doscientas referencias de sidra natural asturiana y vinos del Bierzo.',
122.00, 40, '/static/img/h16_p.jpg', '/static/img/h16_d.jpg');